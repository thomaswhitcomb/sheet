-module(functionsTest).
-include("token.hrl").
-export([
  testSquare/0
  ,testSin0/0
  ,testSin1/0
  ,testTrunc/0
  ,testRound/0
  ,testAvg0/0
  ,testAvg1/0
]).

testSquare() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a1,"square(5)"),
	{_,Value} = sheet:get(Sheet1,a1),
	erltest:assert_true(Value == "25").

testSin0() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a1,"sin(0)"),
	{_,Value} = sheet:get(Sheet1,a1),
	erltest:assert_true(list_to_float(Value) == 0).

testSin1() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a1,"sin(1)"),
	{_,Value} = sheet:get(Sheet1,a1),
	erltest:assert_true(string:substr(Value,1,11) == "8.414709848").

testTrunc() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a1,"trunc(sin(1))"),
	{_,Value} = sheet:get(Sheet1,a1),
	%io:format("truc(sin(1)) ~s~n",[Value]),
	erltest:assert_true(Value == "0").

testRound() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a1,"round(sin(1)+4)"),
	{_,Value} = sheet:get(Sheet1,a1),
	%io:format("truc(sin(1)) ~s~n",[Value]),
	erltest:assert_true(Value == "5").

testAvg0() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a1,"1"),
	Sheet2 = sheet:set(Sheet1,a2,"2"),
	Sheet3 = sheet:set(Sheet2,a3,"3"),
	Sheet4 = sheet:set(Sheet3,a4,"4"),
	Sheet5 = sheet:set(Sheet4,a5,"5"),
	Sheet6 = sheet:set(Sheet5,a6,"avg(a1:a5)"),
	{_,Value} = sheet:get(Sheet6,a6),
	erltest:assert_true(string:substr(Value,1,6) == "3.0000").

testAvg1() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a1,"1"),
	Sheet2 = sheet:set(Sheet1,b1,"2"),
	Sheet3 = sheet:set(Sheet2,c1,"3"),
	Sheet4 = sheet:set(Sheet3,d1,"4"),
	Sheet5 = sheet:set(Sheet4,e1,"5"),
	Sheet6 = sheet:set(Sheet5,f1,"avg(a1:e1)"),
	{_,Value} = sheet:get(Sheet6,f1),
	erltest:assert_true(string:substr(Value,1,6) == "3.0000").









