-module(performanceTest).
-include("token.hrl").
-export([
  timeSimpleSet/0
	,timeComplexSet/0
	,timeComplexSetWithFunctionCalls/0
]).


 timeSimpleSet() ->
  Sheet = sheet:new(),
	sheet:set(Sheet,a2,"10"),
 	erltest:assert_true(1==1).

 timeComplexSet() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a2,"10"),
  sheet:set(Sheet1,a1,"((2+3)*(3)+2)/(a2*5+232)-(434)*589/3"),
 	erltest:assert_true(1==1).

 timeComplexSetWithFunctionCalls() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a2,"10"),
  sheet:set(Sheet1,a1,"((2+3)*(3)+2)/(a2*5+square(3))+square(square(2))"),
 	erltest:assert_true(1==1).
