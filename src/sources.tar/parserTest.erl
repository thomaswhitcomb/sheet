-module(parserTest).
-include("token.hrl").
-export([
  testInteger/0
  ,testIntegerPlusInteger/0
  ,testIntegerPlusIntegerTimesInteger/0
  ,testIntegerTimesIntegerPlusInteger/0
  ,testIntegerTimesIntegerPlusIntegerWithParens/0
  ,testFunction/0
  ,testComplexFunction/0
  ,testParseOfIntegerPlusInteger/0
  ,testParseOfComplexFunction/0
  ,testParseOfBadComplexFunction/0
  ,testParseOfSuperComplexFunction/0
  ,testParseOfBadSuperComplexFunction/0
  ,testParseOfFunctionInFunction/0
  ,testParseOfString/0
  ,testParseOfStringWithOtherNonString1/0
  ,testParseOfStringWithOtherNonString2/0
  ,testParseTwoOperandsNoOperator/0
  ,testParseOfJustList0/0
  ,testParseOfListInFunction0/0
  ,testParseOfListInFunction1/0
  ,testParseOfListInFunction2/0
  ,testParseOfListInFunction3/0
  ,testParseOfListInFunction4/0
]).

testInteger() ->
  Result = parser:normalize([{?NUMBER,1}]),
	erltest:assert_true(Result == "t").

testIntegerPlusInteger() ->
  Result = parser:normalize([{?NUMBER,1},{?OPERATOR,plus},{?NUMBER,2}]),
	erltest:assert_true(Result == "tot").

testIntegerPlusIntegerTimesInteger() ->
  Result = parser:normalize([{?NUMBER,1},{?OPERATOR,plus},{?NUMBER,2},{?OPERATOR,times},{?NUMBER,3}]),
	erltest:assert_true(Result == "totot").
 
 testIntegerTimesIntegerPlusInteger() ->
   Result = parser:normalize([{?NUMBER,1},{?OPERATOR,times},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,3}]),
 	erltest:assert_true(Result == "totot").
 
 testIntegerTimesIntegerPlusIntegerWithParens() ->
   Result = parser:normalize([{?NUMBER,1},{?OPERATOR,times},{?OPERATOR,lparen},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,3},{?OPERATOR,rparen}]),
 	erltest:assert_true(Result == "to{tot}").

 testFunction() ->
   Result = parser:normalize([{?FUNCTION,square},{?OPERATOR,lparen},{?NUMBER,2},{?OPERATOR,comma},{?NUMBER,3},{?OPERATOR,rparen}]),
 	erltest:assert_true(Result == "f{t,t}").
 
 testComplexFunction() ->
   Result = parser:normalize([{?VARIABLE,abc},{?OPERATOR,plus},{?FUNCTION,square},{?OPERATOR,lparen},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,5},{?OPERATOR,comma},{?OPERATOR,lparen},{?NUMBER,3},{?OPERATOR,rparen},{?OPERATOR,rparen}]),
 	erltest:assert_true(Result == "tof{tot,{t}}").

testParseOfIntegerPlusInteger() ->
  Result = parser:parse([{?NUMBER,1},{?OPERATOR,plus},{?NUMBER,2}]),
	erltest:assert_true(Result == ok).

 testParseOfComplexFunction() ->
   Result = parser:parse([{?VARIABLE,abc},{?OPERATOR,plus},{?FUNCTION,square},{?OPERATOR,lparen},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,5},{?OPERATOR,comma},{?OPERATOR,lparen},{?NUMBER,3},{?OPERATOR,rparen},{?OPERATOR,rparen}]),
 	erltest:assert_true(Result == ok).

 testParseOfBadComplexFunction() ->
   Result = parser:parse([{?VARIABLE,abc},{?OPERATOR,plus},{?FUNCTION,square},{?OPERATOR,lparen},{?NUMBER,2},{?NUMBER,5},{?OPERATOR,comma},{?OPERATOR,lparen},{?NUMBER,3},{?OPERATOR,rparen},{?OPERATOR,rparen}]),
 	erltest:assert_true(Result == fail).

 testParseOfSuperComplexFunction() ->
  Tokens = tokenizer:tokenize("((2+3)*(3)+2)/(a1*5+square(3))+square(square(2))"),
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == ok).

 testParseOfBadSuperComplexFunction() ->
  Tokens = tokenizer:tokenize("((2+3)*(3)+2)/(a1*5+square(3)3)+square(square(2))"),
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == fail).

 testParseOfFunctionInFunction() ->
  Tokens = tokenizer:tokenize("square(square(2))"),
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == ok).

 testParseOfString() ->
  Tokens = tokenizer:tokenize("\"abc\""),
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == ok).

 testParseOfStringWithOtherNonString1() ->
  Tokens = tokenizer:tokenize("5+\"abc\""),
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == fail).

 testParseOfStringWithOtherNonString2() ->
  Tokens = tokenizer:tokenize("(\"abc\")"),
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == fail).

 testParseTwoOperandsNoOperator() ->
  Tokens = tokenizer:tokenize("5 4"),
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == fail).

 testParseOfJustList0() ->
  Tokens = tokenizer:tokenize("a1:c1"), % should fail.
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == fail).

 testParseOfListInFunction0() ->
  Tokens = tokenizer:tokenize("avg(a1:c1)"), % should succeed.
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == ok).

 testParseOfListInFunction1() ->
  Tokens = tokenizer:tokenize("avg(a1:c1,2)"), % should fail.
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == fail).

 testParseOfListInFunction2() ->
  Tokens = tokenizer:tokenize("avg(2,a1:c1)"), % should fail.
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == fail).

 testParseOfListInFunction3() ->
  Tokens = tokenizer:tokenize("avg(2,a1:c1)"), % should fail.
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == fail).

 testParseOfListInFunction4() ->
  Tokens = tokenizer:tokenize("avg(d1,a1:c1)"), % should fail.
	Result = parser:parse(Tokens),
 	erltest:assert_true(Result == fail).
