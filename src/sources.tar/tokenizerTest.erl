-module(tokenizerTest).
-include("token.hrl").
-export([
  testString1/0
  ,testVariable1/0
  ,testVariable2/0
  ,testVariable3/0
  ,testInteger1/0
  ,testInteger2/0
  ,testBlanks1/0
  ,testBlanks2/0
  ,testBlanks3/0
  ,testMath1/0
  ,testMath2/0
  ,testFloat/0
  ,testEquality/0
  ,testLessThanOrEqual/0
  ,testGreaterThanOrEqual/0
  ,testNotEqual/0
  ,testLessThan/0
  ,testGreaterThan/0
  ,testList01/0
  ,testList02/0
  ,testList03/0
  ,testList04/0
  ,testList05/0
  ,testList06/0
]).

testString1() ->
  Tokens = tokenizer:tokenize("\"aBcDef\""),
	erltest:assert_true(Tokens == [{?STRING,"aBcDef"}]).

testVariable1() ->
  Tokens = tokenizer:tokenize("A1"),
	erltest:assert_true(Tokens == [{?VARIABLE,a1}]).

testVariable2() ->
  Tokens = tokenizer:tokenize("aA1123"),
	erltest:assert_true(Tokens == [{?VARIABLE,aa1123}]).

testVariable3() ->
  Tokens = tokenizer:tokenize("ba0"),
	erltest:assert_true(Tokens == [{?VARIABLE,ba0}]).

testInteger1() ->
  Tokens = tokenizer:tokenize("12345"),
	erltest:assert_true(Tokens == [{?NUMBER,12345}]).

testInteger2() ->
  Tokens = tokenizer:tokenize("-1"),
	erltest:assert_true(Tokens == [{?NUMBER,-1}]).

testBlanks1() ->
  Tokens = tokenizer:tokenize("  -1  "),
	erltest:assert_true(Tokens == [{?NUMBER,-1}]).

testBlanks2() ->
  Tokens = tokenizer:tokenize("  aa1123  "),
	erltest:assert_true(Tokens == [{?VARIABLE,aa1123}]).

testBlanks3() ->
  Tokens = tokenizer:tokenize("  aa1 123  "),
	erltest:assert_true(Tokens == [{?VARIABLE,aa1},{?NUMBER,123}]).

testMath1() ->
  Tokens = tokenizer:tokenize("  aa1+123  "),
	erltest:assert_true(Tokens == [{?VARIABLE,aa1},{?OPERATOR,plus},{?NUMBER,123}]).

testMath2() ->
  Tokens = tokenizer:tokenize("  aa1+123 * 66 /45 "),
	erltest:assert_true(Tokens == [{?VARIABLE,aa1},{?OPERATOR,plus},{?NUMBER,123},{?OPERATOR,times},{?NUMBER,66},{?OPERATOR,divide},{?NUMBER,45}]).

testFloat() ->
  Tokens = tokenizer:tokenize(" 34.5 + 23.999 "),
	erltest:assert_true(Tokens == [{?NUMBER,34.5},{?OPERATOR,plus},{?NUMBER,23.999}]).

testEquality() ->
  Tokens = tokenizer:tokenize(" 34.5 == 23.999 "),
	erltest:assert_true(Tokens == [{?NUMBER,34.5},{?OPERATOR,equality},{?NUMBER,23.999}]).

testLessThanOrEqual() ->
  Tokens = tokenizer:tokenize(" 34.5 <= 23.999 "),
	erltest:assert_true(Tokens == [{?NUMBER,34.5},{?OPERATOR,lessThanOrEqual},{?NUMBER,23.999}]).

testGreaterThanOrEqual() ->
  Tokens = tokenizer:tokenize(" 34.5 >= 23.999 "),
	erltest:assert_true(Tokens == [{?NUMBER,34.5},{?OPERATOR,greaterThanOrEqual},{?NUMBER,23.999}]).

testNotEqual() ->
  Tokens = tokenizer:tokenize(" 34.5 != 23.999 "),
	erltest:assert_true(Tokens == [{?NUMBER,34.5},{?OPERATOR,notEqual},{?NUMBER,23.999}]).

testGreaterThan() ->
  Tokens = tokenizer:tokenize(" 34.5 > 23.999 "),
	erltest:assert_true(Tokens == [{?NUMBER,34.5},{?OPERATOR,greaterThan},{?NUMBER,23.999}]).

testLessThan() ->
  Tokens = tokenizer:tokenize(" 34.5 < 23.999 "),
	erltest:assert_true(Tokens == [{?NUMBER,34.5},{?OPERATOR,lessThan},{?NUMBER,23.999}]).

testList01() ->
  Tokens = tokenizer:tokenize(" a1:a10 "),
	erltest:assert_true(Tokens == [{?LIST,{"a",1},{"a",10}}]).

testList02() ->
  Tokens = tokenizer:tokenize(" a1:f1 "),
	erltest:assert_true(Tokens == [{?LIST,{"a",1},{"f",1}}]).
	
testList03() ->
  Tokens = tokenizer:tokenize(" g1:g1 "),
	erltest:assert_true(Tokens == [{?LIST,{"g",1},{"g",1}}]).
	
testList04() ->
  try 
    tokenizer:tokenize(" a2:f1 ")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,tokenizer,_} -> erltest:pass()
	end.

testList05() ->
  try 
    tokenizer:tokenize(" aa2:a5 ")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,tokenizer,_} -> erltest:pass()
	end.

testList06() ->
  try 
    tokenizer:tokenize(" a2:ac6 ")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,tokenizer,_} -> erltest:pass()
	end.
