-module(compilerTest).
-include("token.hrl").
-export([
  testGetVariables1/0
	,testGetVariables2/0
	,testGetVariables3/0
	,testGetVariables4/0
	,testGetVariables5/0
	,testGetVariables6/0
  ,testFunctionIntegerCompile/0
  ,testFunctionCompile1/0
  ,testFunctionCompile2/0
  ,testFunctionCompile3/0
  ,testFunctionCompile4/0
  ,testFunctionCompile5/0
  ,testFunctionCompile6/0
  ,testText01/0
]).

testGetVariables1() ->
  Postfix = compiler:compile("3+a1+5"),
	Variables = compiler:getVariables(Postfix),
	erltest:assert_true(length(Variables) == 1),
	erltest:assert_true(Variables == [a1]).

testGetVariables2() ->
  Postfix = compiler:compile("3+a1+a2+7+a787"),
	Variables = compiler:getVariables(Postfix),
	erltest:assert_true(length(Variables) == 3),
	erltest:assert_true(Variables == [a1,a2,a787]).

testGetVariables3() ->
  Postfix = compiler:compile("3+a1+a2+7+a2"),
	Variables = compiler:getVariables(Postfix),
	erltest:assert_true(length(Variables) == 2),
	erltest:assert_true(Variables == [a1,a2]).

testGetVariables4() ->
  Postfix = compiler:compile("3+7"),
	Variables = compiler:getVariables(Postfix),
	erltest:assert_true(length(Variables) == 0).
  
testGetVariables5() ->
  Postfix = compiler:compile("sum(a1:e1)"),
	Variables = compiler:getVariables(Postfix),
	erltest:assert_true(length(Variables) == 5),
	erltest:assert_true(Variables == [a1,b1,c1,d1,e1]).
  
testGetVariables6() ->
  Postfix = compiler:compile("sum(a1:a10)"),
	Variables = compiler:getVariables(Postfix),
	erltest:assert_true(length(Variables) == 10),
	erltest:assert_true(Variables == [a1,a2,a3,a4,a5,a6,a7,a8,a9,a10]).
  
testFunctionIntegerCompile() ->
  Postfix = compiler:compile("5"),
	erltest:assert_true(Postfix == [{?NUMBER,5}]).
  
testFunctionCompile1() ->
  Postfix = compiler:compile("square(5+2)+3"),
	erltest:assert_true(Postfix == [{?NUMBER,5},{?NUMBER,2},{?OPERATOR,plus},{?FUNCTION,square},{?NUMBER,3},{?OPERATOR,plus}]).

testFunctionCompile2() ->
  Postfix = compiler:compile("2+square(5+2)+3"),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?NUMBER,5},{?NUMBER,2},{?OPERATOR,plus},{?FUNCTION,square},{?OPERATOR,plus},{?NUMBER,3},{?OPERATOR,plus}]).

testFunctionCompile3() ->
  Postfix = compiler:compile("square(5*2)*3"),
	erltest:assert_true(Postfix == [{?NUMBER,5},{?NUMBER,2},{?OPERATOR,times},{?FUNCTION,square},{?NUMBER,3},{?OPERATOR,times}]).

testFunctionCompile4() ->
  Postfix = compiler:compile("(1+2)*3+square(5*2)*3"),
	erltest:assert_true(Postfix == [{?NUMBER,1},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,3},{?OPERATOR,times},{?NUMBER,5},{?NUMBER,2},{?OPERATOR,times},{?FUNCTION,square},{?NUMBER,3},{?OPERATOR,times},{?OPERATOR,plus}]).

testFunctionCompile5() ->
  Postfix = compiler:compile("(1+2)*(3+square(5*2))*3"),
	erltest:assert_true(Postfix == [{?NUMBER,1},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,3},{?NUMBER,5},{?NUMBER,2},{?OPERATOR,times},{?FUNCTION,square},{?OPERATOR,plus},{?OPERATOR,times},{?NUMBER,3},{?OPERATOR,times}]).

testFunctionCompile6() ->
  Postfix = compiler:compile("ifthenelse(a1,5,6)"),
	erltest:assert_true(Postfix == [{?VARIABLE,a1},{?NUMBER,5},{?NUMBER,6},{?FUNCTION,ifthenelse}]).

testText01() ->
  Postfix = compiler:compile("\"this is some text\""),
	erltest:assert_true(Postfix == [{?STRING,"this is some text"}]).
