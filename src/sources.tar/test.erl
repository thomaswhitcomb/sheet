-module(test).
-export([
  test/0
]).

test() -> blah:maggot().
