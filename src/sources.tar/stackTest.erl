-module(stackTest).
-export([
  testStackPush1/0
  ,testStackPush2/0
  ,testStackPop1/0
  ,testStackPop2/0
  ,testStackTop1/0
  ,testStackTop2/0
]).

testStackPush1() ->
  Stack = stack:new(),
	Stack1 = stack:push(Stack,1),
	erltest:assert_true(stack:size(Stack1) == 1).

testStackPush2() ->
  Stack = stack:new(),
	Stack1 = stack:push(Stack,1),
	Stack2 = stack:push(Stack1,1),
	erltest:assert_true(stack:size(Stack2) == 2).


testStackPop1() ->
  Stack = stack:new(),
	Stack1 = stack:push(Stack,1),
	erltest:assert_true({1,[]} == stack:pop(Stack1)).

testStackPop2() ->
  Stack = stack:new(),
	Stack1 = stack:push(Stack,1),
	Stack2 = stack:push(Stack1,2),
	{Top1,Stack3} = stack:pop(Stack2),
	erltest:assert_true(2 == Top1 ),
	{Top2,_Stack4} = stack:pop(Stack3),
	erltest:assert_true(1 == Top2).

testStackTop1() ->
  Stack = stack:new(),
	Stack1 = stack:push(Stack,1),
	Top = stack:top(Stack1),
	erltest:assert_true(1 == Top),
	erltest:assert_true(stack:size(Stack1) == 1).

testStackTop2() ->
  Stack = stack:new(),
	Stack1 = stack:push(Stack,1),
	Stack2 = stack:push(Stack1,2),
	Top = stack:top(Stack2),
	erltest:assert_true(2 == Top ),
	erltest:assert_true(stack:size(Stack2) ==2 ).
