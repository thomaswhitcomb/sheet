-module(sheetTest).
-include("token.hrl").
-export([
  testSimpleSetGet1/0
  ,testSimpleSetGet2/0
  ,testSimpleSetGet3/0
  ,testSimpleSetGet4/0
  ,testUndefined1/0
  ,testCacheHit/0
  ,test1DefaultVariable/0
  ,test3Variable/0
  ,testMultiLevelVariable/0
  ,testCells1/0
  ,testCalc1/0
  ,testGetFormula/0
  ,testFormula01/0
	,testClear01/0
	,testClear02/0
	,testCircularity01/0
	,testCircularity02/0
	,testCircularity03/0
	,testCircularity04/0
	,testCircularity05/0
	,testCircularity06/0
	,testCircularity07/0
	,testCircularity08/0
	,testCircularity09/0
	,testCircularity10/0
	,testCircularity11/0
	,testCircularity12/0
	,testMixModeAddition/0
	,testLoad0/0
	,testLoad1/0
	,testLoad2/0
	,testLoad3/0
	,testLoad4/0
	,testLoad5/0
	,testLoad6/0
	,testLoad7/0
	,testLoad8/0
]).

testSimpleSetGet1() ->
	Sheet = sheet:set(sheet:new(),a1,"5"),
	{_,Value} = sheet:get(Sheet,a1),
	erltest:assert_true("5" == Value).

testSimpleSetGet2() ->
	Sheet = sheet:set(sheet:new(),a1,"5+3-(1)"),
	{_,Value} = sheet:get(Sheet,a1),
	erltest:assert_true("7" == Value).

testSimpleSetGet3() ->
	Sheet = sheet:set(sheet:new(),a1,"(1+2)*(3+square(5*2))*3"),
	{_,Value} = sheet:get(Sheet,a1),
	erltest:assert_true(Value == "927").

testSimpleSetGet4() ->
	Sheet = sheet:set(sheet:new(),a1,"\"this is a string\""),
	{_,Value} = sheet:get(Sheet,a1),
	erltest:assert_true(Value == "this is a string").

testUndefined1() ->
	{_,Value} = sheet:get(sheet:new(),a1),
	erltest:assert_true(Value == "0").

testCacheHit() ->
	Sheet = sheet:set(sheet:new(),a1,"5"),
	{Sheet1,V1} = sheet:get(Sheet,a1),
	erltest:assert_true(V1 == "5"),
	{Sheet2,V2} = sheet:get(Sheet1,a1),
	erltest:assert_true(V2 == "5"),
	{_Sheet3,V3} = sheet:get(Sheet2,a1),
	erltest:assert_true(V3 == "5"),
	erltest:pass().

test1DefaultVariable() ->
	{_,Value} = sheet:get(sheet:new(),a1),
	erltest:assert_true(Value == "0").

test3Variable() ->
	Sheet = sheet:set(sheet:new(),a1,"1+2"),
	Sheet1 = sheet:set(Sheet,a2,"2"),
	Sheet2 = sheet:set(Sheet1,a3,"3"),
	Sheet3 = sheet:set(Sheet2,a4,"(a1)*(3+square(5*a2))*a3"),
	{_Sheet4,V1} = sheet:get(Sheet3,a4),
	erltest:assert_true(V1 == "927").

testMultiLevelVariable() ->
	Sheet = sheet:set(sheet:new(),a1,"1+2"),
	Sheet1 = sheet:set(Sheet,a2,"2+a1"),
	Sheet2 = sheet:set(Sheet1,a3,"3+a2*a1"),
	{_Sheet4,V1} = sheet:get(Sheet2,a3),
	erltest:assert_true(V1 == "18").

testCells1() ->
	Sheet = sheet:set(sheet:new(),a1,"1+2"),
	Sheet1 = sheet:set(Sheet,a2,"5+a1"),
	List = sheet:cells(Sheet1),
	List1 = lists:sort(List),
	erltest:assert_true(List1 == [{a1,"1+2","3"},{a2,"5+a1","8"}]).

testCalc1() ->
	Sheet = sheet:set(sheet:new(),a1,"1+2"),
	Sheet1 = sheet:set(Sheet,a2,"5+a1"),
	Sheet2 = sheet:set(Sheet1,d8,"a1+(a2*5)-(a2)"),
	Sheet3 = sheet:calc(Sheet2),
	{_Cells,Cache} = Sheet3,
	List = dict:to_list(Cache),
	List1 = lists:sort(List),
	erltest:assert_true(List1 == [{a1,{?NUMBER,3}},{a2,{?NUMBER,8}},{d8,{?NUMBER,35}}]).

testGetFormula() ->
	Sheet = sheet:set(sheet:new(),a1,"1+2"),
	Sheet1 = sheet:set(Sheet,a2,"5+a1"),
	Formula1 = sheet:getFormula(Sheet1,a2),
	erltest:assert_true(Formula1 == "5+a1" ),
	erltest:assert_true(sheet:getFormula(Sheet1,a1) == "1+2" ).

testFormula01() ->
	Sheet = sheet:set(sheet:new(),a1,"square(5)*2+1"),
	{_Sheet4,Value} = sheet:get(Sheet,a1),
	erltest:assert_true(Value == "51" ).

testClear01() ->
	Sheet = sheet:set(sheet:new(),a1,"5"),
	Sheet1 = sheet:clear(Sheet,a1),
	{_,Value} = sheet:get(Sheet1,a1),
	erltest:assert_true("0" == Value).

testClear02() ->
	Sheet = sheet:set(sheet:new(),a1,"5+2+3"),
	{Sheet1,Value1} = sheet:get(Sheet,a1),
	erltest:assert_true("10" == Value1),
	Sheet2 = sheet:clear(Sheet1,a1),
	{_,Value2} = sheet:get(Sheet2,a1),
	erltest:assert_true("0" == Value2).

testCircularity01() ->
  try
	  sheet:set(sheet:new(),a1,"5+2+a1")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity02() ->
	Sheet =  sheet:set(sheet:new(),a1,"a2"),
  try
	  sheet:set(Sheet,a2,"a1")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity03() ->
	Sheet =  sheet:set(sheet:new(),a1,"a2"),
	Sheet1 =  sheet:set(Sheet,a2,"a3"),
  try
	  sheet:set(Sheet1,a3,"a1")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity04() ->
	Sheet =  sheet:set(sheet:new(),a1,"a2+a2"),
	Sheet1 =  sheet:set(Sheet,a2,"a3+a3"),
  try
	  sheet:set(Sheet1,a3,"a1+a2")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity05() ->
	Sheet =  sheet:set(sheet:new(),a1,"2"),
	Sheet1 =  sheet:set(Sheet,a2,"a4"),
	Sheet2 =  sheet:set(Sheet1,a3,"a2"),
  try
	  sheet:set(Sheet2,a4,"a3")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity06() ->
	Sheet =  sheet:set(sheet:new(),a0,"2"),
	Sheet1 =  sheet:set(Sheet,b0,"a0"),
	Sheet2 =  sheet:set(Sheet1,c0,"a0"),
	Sheet3 =  sheet:set(Sheet2,a1,"2-(-3)"),
	Sheet4 =  sheet:set(Sheet3,d3,"b0+c0"),
  try
	  sheet:set(Sheet4,b1,"b0+d3")
	of
	  _ -> erltest:pass()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:fail()
	end.	

testCircularity07() ->
	Sheet =  sheet:set(sheet:new(),a0,"2"),
	Sheet1 =  sheet:set(Sheet,b0,"a0"),
	Sheet2 =  sheet:set(Sheet1,c0,"a0+b1"),
	Sheet3 =  sheet:set(Sheet2,a1,"2-(-3)"),
	Sheet4 =  sheet:set(Sheet3,d3,"b0+c0"),
  try
	  sheet:set(Sheet4,b1,"b0+d3")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity08() ->
	Sheet =  sheet:set(sheet:new(),d3,"b0+c0"),
	Sheet1 =  sheet:set(Sheet,a1,"2-(-3)"),
	Sheet2 =  sheet:set(Sheet1,c0,"a0+b1"),
	Sheet3 =  sheet:set(Sheet2,b0,"a0"),
	Sheet4 =  sheet:set(Sheet3,a0,"2"),
  try
	  sheet:set(Sheet4,b1,"b0+d3")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity09() ->
	Sheet =  sheet:set(sheet:new(),a0,"1"),
	Sheet1 =  sheet:set(Sheet,a1,"2"),
	Sheet2 =  sheet:set(Sheet1,a2,"3"),
	Sheet3 =  sheet:set(Sheet2,a3,"4"),
	Sheet4 =  sheet:set(Sheet3,a4,"5"),
	Sheet5 =  sheet:set(Sheet4,a5,"6"),
  try
	  sheet:set(Sheet5,a6,"sum(a0:a6)")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity10() ->
	Sheet =  sheet:set(sheet:new(),a0,"1"),
	Sheet1 =  sheet:set(Sheet,b0,"2"),
	Sheet2 =  sheet:set(Sheet1,c0,"3"),
	Sheet3 =  sheet:set(Sheet2,d0,"4"),
	Sheet4 =  sheet:set(Sheet3,e0,"5"),
	Sheet5 =  sheet:set(Sheet4,f0,"6"),
  try
	  sheet:set(Sheet5,g0,"sum(a0:h0)")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity11() ->
  try
	  sheet:set(sheet:new(),a2,"avg(a0:a3)")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testCircularity12() ->
  try
	  sheet:set(sheet:new(),e2,"avg(a2:e2)")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,circularity,_Message} -> erltest:pass()
	end.	

testMixModeAddition() ->
	Sheet =  sheet:set(sheet:new(),a0,"\"abc\""),
	Sheet1 =  sheet:set(Sheet,b0,"2+a0"),
	{_,_Value} =  sheet:get(Sheet1,b0),
	erltest:assert_true(true == true).

testLoad0() ->
  P = sheet:carveIntoProperties(lists:flatten(io_lib:format("a=12~n",[]))),
	erltest:assert_true(P == [{a,"12"}]).

testLoad1() ->
  P = sheet:carveIntoProperties(lists:flatten(io_lib:format("a=12~nb=13~n",[]))),
	erltest:assert_true(P == [{a,"12"},{b,"13"}]).

testLoad2() ->
  P = sheet:carveIntoProperties(lists:flatten(io_lib:format("a=12+cd+5 ~nb=13-5 ~n",[]))),
	erltest:assert_true(P == [{a,"12+cd+5"},{b,"13-5"}]).


testLoad3() ->
  Sheet1 = sheet:load(sheet:new(),lists:flatten(io_lib:format("a=12+5 ~nb=13-(5+5) ",[]))),
	{Sheet2,Value1} = sheet:get(Sheet1,a),
	{_Sheet3,Value2} = sheet:get(Sheet2,b),
	erltest:assert_true(Value1 == "17"),
	erltest:assert_true(Value2 == "3").


testLoad4() ->
  Sheet1 = sheet:load(sheet:new(),lists:flatten(io_lib:format("a=12+5 ~nb=13-(5+5)~n   ",[]))),
	{Sheet2,Value1} = sheet:get(Sheet1,a),
	{_Sheet3,Value2} = sheet:get(Sheet2,b),
	erltest:assert_true(Value1 == "17"),
	erltest:assert_true(Value2 == "3").


testLoad5() ->
  try
    sheet:load(sheet:new(),lists:flatten(io_lib:format("a=12+5 ~nb=13-(5+5~n   ",[])))
	of	
	  _ -> erltest:fail()
	catch
	  throw:{sheet,compiler,_} -> erltest:pass()
	end.

testLoad6() ->
  try
    sheet:load(sheet:new(),lists:flatten(io_lib:format("a=12+5 b=13-(5+5~n   ",[])))
	of	
	  _ -> erltest:fail()
	catch
	  throw:{sheet,tokenizer,_} -> erltest:pass()
	end.

testLoad7() ->
    Sheet = sheet:new(),
    Sheet1 = sheet:load(sheet:new(),""),
	  erltest:assert_true(Sheet1 == Sheet).


testLoad8() ->
  Sheet1 = sheet:load(sheet:new(),lists:flatten(io_lib:format("a =12+5 ~nb=13-(5+5)~n   ",[]))),
	{Sheet2,Value1} = sheet:get(Sheet1,a),
	{_Sheet3,Value2} = sheet:get(Sheet2,b),
	io:format("value1 ~s Value2 ~s~n",[Value1,Value2]),
	erltest:assert_true(Value1 == "17"),
	erltest:assert_true(Value2 == "3").
