-module(postfixerTest).
-include("token.hrl").
-export([
  testIntegerPlusInteger/0
  ,testIntegerPlusIntegerTimesInteger/0
  ,testIntegerTimesIntegerPlusInteger/0
  ,testIntegerTimesIntegerPlusIntegerWithParens/0
  ,testIntegerTimesIntegerPlusIntegerWith1LParen/0
  ,testIntegerTimesIntegerPlusIntegerWith1RParen/0
  ,testLParenIntegerRParen/0
  ,testJustTimes/0
  ,testFunctionWithArity/0
  ,testFunctionWithComplexArity/0
  ,testEquality/0
  ,testNotEquality/0
  ,testLessThan/0
  ,testGreaterThan/0
  ,testGreaterThanOrEqual/0
  ,testLessThanOrEqual/0
  ,testFunctionWithList0/0
  ,testFunctionWithList1/0
]).

testIntegerPlusInteger() ->
  Postfix = postfixer:postfix([{?NUMBER,1},{?OPERATOR,plus},{?NUMBER,2}]),
	erltest:assert_true(Postfix == [{?NUMBER,1},{?NUMBER,2},{?OPERATOR,plus}]).

testIntegerPlusIntegerTimesInteger() ->
  Postfix = postfixer:postfix([{?NUMBER,1},{?OPERATOR,plus},{?NUMBER,2},{?OPERATOR,times},{?NUMBER,3}]),
	erltest:assert_true(Postfix == [{?NUMBER,1},{?NUMBER,2},{?NUMBER,3},{?OPERATOR,times},{?OPERATOR,plus}]).

testIntegerTimesIntegerPlusInteger() ->
  Postfix = postfixer:postfix(
	  [{?NUMBER,1},{?OPERATOR,times},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,3}]),
	erltest:assert_true(Postfix == [{?NUMBER,1},{?NUMBER,2},{?OPERATOR,times},{?NUMBER,3},{?OPERATOR,plus}]).

testIntegerTimesIntegerPlusIntegerWithParens() ->
  Postfix = postfixer:postfix(
	  [{?NUMBER,1},{?OPERATOR,times},{?OPERATOR,lparen},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,3},{?OPERATOR,rparen}]),
	erltest:assert_true(Postfix == [{?NUMBER,1},{?NUMBER,2},{?NUMBER,3},{?OPERATOR,plus},{?OPERATOR,times}]).

testIntegerTimesIntegerPlusIntegerWith1LParen() ->
  try 
    postfixer:postfix( [{?NUMBER,1},{?OPERATOR,times},{?OPERATOR,lparen},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,3}])
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,postfixer,"Unbalanced parens - extra left one"} -> erltest:pass()

	end.
testIntegerTimesIntegerPlusIntegerWith1RParen() ->
  try
    postfixer:postfix( [{?NUMBER,1},{?OPERATOR,times},{?NUMBER,2},{?OPERATOR,plus},{?NUMBER,3},{?OPERATOR,rparen}])
	of
	  _ -> erltest:fail()
  catch
	  throw:{sheet,postfixer,"Unbalanced parens - extra right one"} -> erltest:pass()
	end.	

testLParenIntegerRParen() ->
    Postfix = postfixer:postfix(
	  [{?OPERATOR,lparen},{?NUMBER,1},{?OPERATOR,rparen}]),
	erltest:assert_true(Postfix == [{?NUMBER,1}]).


testJustTimes() ->
  Postfix = postfixer:postfix(
	  [{?OPERATOR,times}]),
	erltest:assert_true(Postfix == [{?OPERATOR,times}]).


testFunctionWithArity() ->
  Postfix = postfixer:postfix(
	[{?FUNCTION,ifthenelse},{?OPERATOR,lparen},{?NUMBER,1},{?NUMBER,2},{?NUMBER,3},{?OPERATOR,rparen}]),
	erltest:assert_true(Postfix == [{?NUMBER,1},{?NUMBER,2},{?NUMBER,3},{?FUNCTION,ifthenelse}]).

testFunctionWithComplexArity() ->
  Tokens = tokenizer:tokenize("ifthenelse(2+3/1,3*4/2,15)"),
	Postfix = postfixer:postfix(Tokens),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?NUMBER,3},{?NUMBER,1},{?OPERATOR,divide},{?OPERATOR,plus},{?NUMBER,3},{?NUMBER,4},{?OPERATOR,times},{?NUMBER,2},{?OPERATOR,divide},{?NUMBER,15},{?FUNCTION,ifthenelse}]).

testEquality() ->
  Tokens = tokenizer:tokenize("(2+3)*1 == 15+5"),
	Postfix = postfixer:postfix(Tokens),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?NUMBER,3},{?OPERATOR,plus},{?NUMBER,1},{?OPERATOR,times},{?NUMBER,15},{?NUMBER,5},{?OPERATOR,plus},{?OPERATOR,equality}]).

testNotEquality() ->
  Tokens = tokenizer:tokenize("(2+3)*1 != 15+5"),
	Postfix = postfixer:postfix(Tokens),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?NUMBER,3},{?OPERATOR,plus},{?NUMBER,1},{?OPERATOR,times},{?NUMBER,15},{?NUMBER,5},{?OPERATOR,plus},{?OPERATOR,notEqual}]).

testLessThan() ->
  Tokens = tokenizer:tokenize("(2+3)*1 < 15+5"),
	Postfix = postfixer:postfix(Tokens),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?NUMBER,3},{?OPERATOR,plus},{?NUMBER,1},{?OPERATOR,times},{?NUMBER,15},{?NUMBER,5},{?OPERATOR,plus},{?OPERATOR,lessThan}]).

testGreaterThan() ->
  Tokens = tokenizer:tokenize("(2+3)*1 > 15+5"),
	Postfix = postfixer:postfix(Tokens),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?NUMBER,3},{?OPERATOR,plus},{?NUMBER,1},{?OPERATOR,times},{?NUMBER,15},{?NUMBER,5},{?OPERATOR,plus},{?OPERATOR,greaterThan}]).

testGreaterThanOrEqual() ->
  Tokens = tokenizer:tokenize("(2+3)*1 >= 15+5"),
	Postfix = postfixer:postfix(Tokens),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?NUMBER,3},{?OPERATOR,plus},{?NUMBER,1},{?OPERATOR,times},{?NUMBER,15},{?NUMBER,5},{?OPERATOR,plus},{?OPERATOR,greaterThanOrEqual}]).

testLessThanOrEqual() ->
  Tokens = tokenizer:tokenize("(2+3)*1 <= square(15+5)"),
	Postfix = postfixer:postfix(Tokens),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?NUMBER,3},{?OPERATOR,plus},{?NUMBER,1},{?OPERATOR,times},{?NUMBER,15},{?NUMBER,5},{?OPERATOR,plus},{?FUNCTION,square},{?OPERATOR,lessThanOrEqual}]).

testFunctionWithList0() ->
  Tokens = tokenizer:tokenize("2+avg(a1:c1)*3"),
	Postfix = postfixer:postfix(Tokens),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?LIST,{"a",1},{"c",1}},{?FUNCTION,avg},{?NUMBER,3},{?OPERATOR,times},{?OPERATOR,plus}]).

testFunctionWithList1() ->
  Tokens = tokenizer:tokenize("2+(avg(a1:c1))*3"),
	Postfix = postfixer:postfix(Tokens),
	erltest:assert_true(Postfix == [{?NUMBER,2},{?LIST,{"a",1},{"c",1}},{?FUNCTION,avg},{?NUMBER,3},{?OPERATOR,times},{?OPERATOR,plus}]).
