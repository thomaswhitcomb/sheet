-module(interpreterTest).
-include("token.hrl").
-export([
  testResolveInteger/0
	,testResolveString/0
	,testResolveList0/0
	,testResolveList1/0
  ,testIntegerIntegerAdd/0
  ,testIntegerIntegerMinus/0
  ,testIntegerIntegerTimes/0
  ,testIntegerIntegerDivide/0
  ,testIntegerIntegerAddIntegerTimes/0
  ,testIntegerIntegerAddInteger/0
  ,testFunctionWithArity/0
  ,testIntegerInteger/0
  ,testIntegerTimes/0
  ,testIntegerDivide/0
  ,testCompileInterpret01/0
  ,testCompileInterpret02/0
  ,testCompileInterpret03/0
  ,testCompileInterpret04/0
  ,testCompileInterpret05/0
  ,testCompileInterpret06/0
  ,testCompileInterpret07/0
  ,testCompileInterpret08/0
  ,testCompileInterpret09/0
  ,testCompileInterpret10/0
  ,testCompileInterpret11/0
  ,testCompileInterpret12/0
  ,testCompileInterpret13/0
  ,testCompileInterpret14/0
  ,testCompileInterpret15/0
  ,testCompileInterpret16/0
  ,testCompileInterpret17/0
  ,testCompileInterpret18/0
  ,testCompileInterpret19/0
  ,testCompileInterpret20/0
  ,testCompileInterpret21/0
  ,testCompileInterpret22/0
  ,testCompileInterpret23/0
  ,testCompileInterpret24/0
  ,testCompileInterpret25/0
  ,testCompileInterpret26/0
  ,testCompileInterpret27/0
  ,testCompileInterpret28/0
  ,testCompileInterpret29/0
  ,testCompileWithDefaultVariable/0
]).
testResolveInteger() ->
  Sheet = sheet:new(),
	Value = interpreter:resolve({?NUMBER,5},Sheet),
	erltest:assert_true(Value == {Sheet,{?NUMBER,5}}).

testResolveString() ->
  Sheet = sheet:new(),
	Value = interpreter:resolve({?STRING,"abc"},Sheet),
	erltest:assert_true(Value == {Sheet,{?STRING,"abc"}}).

testResolveList0() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a1,"1"),
	Sheet2 = sheet:set(Sheet1,a2,"2"),
	Sheet3 = sheet:set(Sheet2,a3,"3"),
	Sheet4 = sheet:set(Sheet3,a4,"4"),
	Sheet5 = sheet:set(Sheet4,a5,"5"),
	Value = interpreter:resolve({?LIST,{"a",1},{"a",5}},Sheet5),
	erltest:assert_true(Value == {Sheet5,{?LIST,[{?NUMBER,1},{?NUMBER,2},{?NUMBER,3},{?NUMBER,4},{?NUMBER,5}]}}).

testResolveList1() ->
  Sheet = sheet:new(),
	Sheet1 = sheet:set(Sheet,a1,"1"),
	Sheet2 = sheet:set(Sheet1,b1,"2"),
	Sheet3 = sheet:set(Sheet2,c1,"3"),
	Sheet4 = sheet:set(Sheet3,d1,"4"),
	Sheet5 = sheet:set(Sheet4,e1,"5"),
	Value = interpreter:resolve({?LIST,{"a",1},{"e",1}},Sheet5),
	erltest:assert_true(Value == {Sheet5,{?LIST,[{?NUMBER,1},{?NUMBER,2},{?NUMBER,3},{?NUMBER,4},{?NUMBER,5}]}}).

testIntegerIntegerAdd() ->
  Postfix = [{?NUMBER,1},{?NUMBER,3},{?OPERATOR,plus}],
  Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,4}).

testIntegerIntegerMinus() ->
  Postfix = [{?NUMBER,5},{?NUMBER,3},{?OPERATOR,minus}],
  Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,2}).

testIntegerIntegerTimes() ->
  Postfix = [{?NUMBER,5},{?NUMBER,3},{?OPERATOR,times}],
  Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,15}).

testIntegerIntegerDivide() ->
  Postfix = [{?NUMBER,6},{?NUMBER,3},{?OPERATOR,divide}],
  Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,2}).

testIntegerIntegerAddIntegerTimes() ->
  Postfix = [{?NUMBER,1},{?NUMBER,3},{?OPERATOR,plus},{?NUMBER,2},{?OPERATOR,times}],
  Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,8}).

testFunctionWithArity() ->
	Postfix = [{?NUMBER,1},{?NUMBER,2},{?NUMBER,3},{?FUNCTION,ifthenelse}],
  Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,2}).

testIntegerIntegerAddInteger() ->
  Postfix = [{?NUMBER,1},{?NUMBER,3},{?OPERATOR,plus},{?NUMBER,2}],
	try
	  interpreter:run(Postfix)
	of	
	  _ -> erltest:fail()
	catch 
	  throw:{sheet,interpreter,_Message} -> erltest:pass()
	end.

testIntegerInteger() ->
  Postfix = [{?NUMBER,1},{?NUMBER,3}],
	try
    interpreter:run(Postfix)
	of
	  _ -> erltest:fail()
  catch	
	  throw:{sheet,interpreter,_Message} -> erltest:pass()
	end.

testIntegerTimes() ->
  Postfix = [{?NUMBER,1},{?OPERATOR,times}],
	try
    interpreter:run(Postfix)
	of
	  _ -> erltest:fail()
  catch	
	  throw:{sheet,interpreter,_Message} -> erltest:pass()
	end.

testIntegerDivide() ->
  Postfix = compiler:compile("5/1"),
  Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,5}).

testCompileInterpret01() ->
  Postfix = compiler:compile("2*(5+3)/2"),
	Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,8}).

testCompileInterpret02() ->
  Postfix = compiler:compile("10/(2+(5+3))"),
	Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,1}).

testCompileInterpret03() ->
  Postfix = compiler:compile("10/(2+(5+3))*(10+1)"),
	Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,11}).

testCompileInterpret04() ->
  Postfix = compiler:compile("10-(2+5-(3))-(7)"),
	Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,-1}).

testCompileInterpret05() ->
  Postfix = compiler:compile("(1+2)*(3+square(5*2))*3"),
	Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,927}).

testCompileWithDefaultVariable() ->
  Postfix = compiler:compile("a1"),
	Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,0}).

testCompileInterpret06() ->
  Postfix = compiler:compile("(1+((2)))*(3+square(5*square(2)))*4"),
	Value = interpreter:run(Postfix),
	erltest:assert_true(Value == {?NUMBER,4836}).

testCompileInterpret07() ->
  try
    compiler:compile("(1+((2)))*(3 4+square(5*square(2)))*4")
	of
	  _ -> erltest:fail()
	catch	
	  throw:{sheet,compiler,_Message} -> erltest:pass()
	end.	

testCompileInterpret08() ->
  try
    compiler:compile("a1-b4*b9+square 5")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,compiler,_Message} -> erltest:pass()
	end.

testCompileInterpret09() ->
  try
    compiler:compile("(5+3))")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,compiler,_Message} -> erltest:pass()
	end.
		
testCompileInterpret10() ->
  try
    compiler:compile("(5$3)")
	of
	  _ -> erltest:fail()
	catch
	  throw:{sheet,tokenizer,_Message} -> erltest:pass()
	end.	
		
testCompileInterpret11() ->
  try
    compiler:compile("4++")
	of	
	  _ -> erltest:fail()
	catch
	  throw:{sheet,compiler,_Message} -> erltest:pass()
	end.	

testCompileInterpret12() ->
  try
    compiler:compile("4r33")
	of	
	  _ -> erltest:fail()
	catch
	  throw:{sheet,compiler,_Message} -> erltest:pass()
	end.	

testCompileInterpret13() ->
  P = compiler:compile("3.14*1"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,3.14} ).

testCompileInterpret14() ->
  P = compiler:compile("3.14+1.86+1"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,6.000} ).

testCompileInterpret15() ->
  P = compiler:compile("ifthenelse(2+3/1,3*4/2,15)"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,6} ).

testCompileInterpret16() ->
  P = compiler:compile("3+ifthenelse(2+3/1,3*4/2,15)*2"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,15} ).

testCompileInterpret17() ->
  P = compiler:compile("(7-(3))/2==10/5"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,1} ).

testCompileInterpret18() ->
  P = compiler:compile("7+3==10/5"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,0} ).

testCompileInterpret19() ->
  P = compiler:compile("(7+3)/2!=10/1"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,1} ).

testCompileInterpret20() ->
  P = compiler:compile("(7+3)/2!=10/2"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,0} ).

testCompileInterpret21() ->
  P = compiler:compile("square(5)+4 < 30-(1)"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,0} ).

testCompileInterpret22() ->
  P = compiler:compile("square(1)+4 < 30-(1)"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,1} ).

testCompileInterpret23() ->
  P = compiler:compile("square(5)+4 <= 30-(1)"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,1} ).

testCompileInterpret24() ->
  P = compiler:compile("square(6)+4 <= 30-(1)"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,0} ).

testCompileInterpret25() ->
  P = compiler:compile("square(5)+5 > 30-(1)"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,1} ).

testCompileInterpret26() ->
  P = compiler:compile("square(5)+5 > 30"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,0} ).

testCompileInterpret27() ->
  P = compiler:compile("square(5)+5 >= 30+0+0+0+0+0"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,1} ).

testCompileInterpret28() ->
  P = compiler:compile("square(1)+5 >= 30+7"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,0} ).

testCompileInterpret29() ->
  P = compiler:compile("square(5)/5"),
	Value = interpreter:run(P),
	erltest:assert_true(Value == {?NUMBER,5} ).
