-module(sheetServerTest).
-export([
  testStartStop/0
  ,testSimpleSet1/0
  ,testSimpleSet2/0
  ,testSimpleSetGet1/0
  ,testSimpleSetGet2/0
  ,testSimpleSetGet3/0
]).

testStartStop() ->
  Pid = sheetServer:start(),
	Ok = sheetServer:stop(Pid),
	erltest:assert_true(ok == Ok).

testSimpleSet1() ->
  Pid = sheetServer:start(),
	Ok = sheetServer:set(Pid,a1,"5"),
	Stop = sheetServer:stop(Pid),
	erltest:assert_true(Stop == ok),
	erltest:assert_true(ok == Ok).

testSimpleSet2() ->
  Pid = sheetServer:start(),
	Ok = sheetServer:set(Pid,a1,"5+3"),
	Stop = sheetServer:stop(Pid),
	erltest:assert_true(Stop == ok),
	erltest:assert_true(ok == Ok).

testSimpleSetGet1() ->
  Pid = sheetServer:start(),
	Ok = sheetServer:set(Pid,a1,"5"),
	{Ok,Value} = sheetServer:get(Pid,a1),
	Stop = sheetServer:stop(Pid),
	erltest:assert_true(Stop == ok),
	erltest:assert_true("5" == Value),
	erltest:assert_true(Ok == ok).

testSimpleSetGet2() ->
  Pid = sheetServer:start(),
	Ok = sheetServer:set(Pid,a1,"5+3-(1)"),
	{Ok,Value} = sheetServer:get(Pid,a1),
	Stop = sheetServer:stop(Pid),
	erltest:assert_true(Stop == ok),
	erltest:assert_true("7" == Value),
	erltest:assert_true(Ok == ok).

testSimpleSetGet3() ->
  Pid = sheetServer:start(),
	sheetServer:set(Pid,a1,"(1+2)*(3+square(5*2))*3"),
	{ok,One} = sheetServer:get(Pid,a1),
	Stop = sheetServer:stop(Pid),
	erltest:assert_true(Stop == ok),
	erltest:assert_true(One == "927").
