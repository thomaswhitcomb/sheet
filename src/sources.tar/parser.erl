-module(parser).
-include("token.hrl").
-export([
  parse/1
  ,normalize/1
]).

parse(L) -> 
  S = normalize(L),
  %io:format("Will reduce ~s~n",[S]),
	applyRules(S).

applyRules(S) ->
  Status = applyEachRule(S,stopCondition(),rules()),
	case Status of
	  ok -> ok;
		S1 -> 
		  case S1 == S of
			  true -> fail;
				false -> applyRules(S1)
			end
	end.		

applyEachRule(Stop,Stop,_) -> ok;
applyEachRule(Data,_,[]) -> Data;
applyEachRule(Data,Stop,[Rule|RestOfRules]) ->
  {Before,After} = Rule,
  {ok,NewData,C} = regexp:gsub(Data,Before,After),
	case C of
		0 -> applyEachRule(NewData,Stop,RestOfRules);
	  _ -> %io:format("reduced ~s to ~s~n",[Data,NewData]),
		  NewData 
	end.	

normalize([]) ->[];
normalize([{?VARIABLE,_}|Rest]) ->
  append(t,normalize(Rest));
normalize([{?NUMBER,_}|Rest]) ->
  append(t,normalize(Rest));
normalize([{?OPERATOR,lparen}|Rest]) ->
  append("{",normalize(Rest));
normalize([{?OPERATOR,rparen}|Rest]) ->
  append("}",normalize(Rest));
normalize([{?OPERATOR,comma}|Rest]) ->
  append(",",normalize(Rest));
normalize([{?OPERATOR,_}|Rest]) ->
  append(o,normalize(Rest));
normalize([{?STRING,_}|Rest]) ->
  append(s,normalize(Rest));
normalize([{?LIST,_,_}|Rest]) ->
  append(l,normalize(Rest));
normalize([{?FUNCTION,_}|Rest]) ->
  append(f,normalize(Rest)).

append([H],List) ->
  [H|List];
append(A,List) ->
  [H|_] = atom_to_list(A),
  [H|List].

  stopCondition() -> "x".
	rules() ->[
		{"^t$","x"},    % a single terminal (number or variable)
		{"^s$","x"},    % a single string
		{"f{t}","t"},   % function with a single parm
		{"f{l}","t"},   % function with a list
	  {"{t}","t"},    % terminal with parens
		{"tot","t"},    % terminal operator terminal
		{"f{t,t","f{t"} % function with multiple terms
		].
